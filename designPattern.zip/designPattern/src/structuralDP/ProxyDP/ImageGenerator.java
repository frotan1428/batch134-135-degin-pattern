package structuralDP.ProxyDP;

public interface ImageGenerator {

    void showImageName();


}
