package structuralDP.compositeDP;

import java.util.List;

public abstract class Department {

    //name of department

    abstract String getName();

    //list of department
    abstract List<String> getEmployee();
}
