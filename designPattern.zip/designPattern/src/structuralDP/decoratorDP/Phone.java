package structuralDP.decoratorDP;

public interface Phone {
    String getName();
    int cameraCount();

    double getPrice();
    ///more functionality
}
