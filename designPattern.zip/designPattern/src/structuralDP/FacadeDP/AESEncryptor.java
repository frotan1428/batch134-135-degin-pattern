package structuralDP.FacadeDP;

public class AESEncryptor {

    public void encrypt(String text){
        System.out.println("<AES> "+ text+"<AES> ");
    }
}
