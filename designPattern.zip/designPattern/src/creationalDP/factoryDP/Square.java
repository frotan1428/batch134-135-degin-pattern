package creationalDP.factoryDP;

public class Square implements Shape {
    public void draw(){
        System.out.println("Square has been drawn");
    }
}
