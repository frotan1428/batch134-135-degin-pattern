package creationalDP.factoryDP;

public class Circle implements Shape {
    public void draw(){
        System.out.println("Circle has been drawn");
    }
}
