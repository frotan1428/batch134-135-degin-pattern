package creationalDP.abstractFactoryDP;

public interface Color {
    void fill();
}
