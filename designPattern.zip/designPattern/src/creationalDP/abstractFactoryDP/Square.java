package creationalDP.abstractFactoryDP;

public class Square implements Shape {
    public void draw(){
        System.out.println("Square has been drawn");
    }
}
