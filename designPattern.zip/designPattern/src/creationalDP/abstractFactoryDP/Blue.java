package creationalDP.abstractFactoryDP;

public class Blue implements Color{
    @Override
    public void fill() {
        System.out.println("Filled with blue color");
    }
}
