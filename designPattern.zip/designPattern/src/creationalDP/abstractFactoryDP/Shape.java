package creationalDP.abstractFactoryDP;

public interface Shape {
    void draw();
}
