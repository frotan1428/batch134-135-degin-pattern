package behavioralDP.observerDp;

public interface Chanel {


    void update (String news);//it is used for update news

    void printNews();// to see news on the chanel.

}
