package behavioralDP.mediatorDp;

public class MediatorRunner {
    public static void main(String[] args) {

        MediatorRunner runner= new MediatorRunner();
        runner.mediator();

    }

    void mediator(){

        MessageDispatcher dispatcher= new MessageDispatcher();

        // create teacher object

        Teacher chemistryTeacher= new MessageTeacher("ChemistryTeacher",dispatcher);
        Teacher mathTeacher= new MessageTeacher("MathematicsTeacher",dispatcher);
        Teacher physicsTeacher= new MessageTeacher("physicsTeacher",dispatcher);
        Teacher biologyTeacher= new MessageTeacher("BiologyTeacher",dispatcher);

        //register teacher to the dispatcher

        dispatcher.register("chemistry",chemistryTeacher);
        dispatcher.register("mathematics",mathTeacher);
        dispatcher.register("physics",physicsTeacher);
        dispatcher.register("biology",biologyTeacher);

        //one teacher can ask any question from other
        chemistryTeacher.sendMessage("mathematics","message about Math");
        chemistryTeacher.sendMessage("physics","message about Physics");
        chemistryTeacher.sendMessage("biology","message about Biology");




    }
}
