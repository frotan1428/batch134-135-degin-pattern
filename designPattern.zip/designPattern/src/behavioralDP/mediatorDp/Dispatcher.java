package behavioralDP.mediatorDp;

public interface Dispatcher {

    void dispatch(String topic,String message);

}
